# 🥦 CaloriTrack — Guide de déploiement PWA

## 📱 Résultat final
Une app installable sur iPhone depuis Safari, sans App Store, gratuitement.

---

## Étape 1 — Créer un compte GitHub
👉 https://github.com → "Sign up" (gratuit)

---

## Étape 2 — Créer un repository
1. Clique sur **"New"** (bouton vert)
2. Nom : `caloritrack`
3. Visibilité : **Public**
4. Clique **"Create repository"**

---

## Étape 3 — Uploader les fichiers
1. Dans le repo, clique **"uploading an existing file"**
2. Glisse-dépose **tous les fichiers du zip** (respecte la structure des dossiers)
3. Message de commit : `Initial commit`
4. Clique **"Commit changes"**

---

## Étape 4 — Déployer sur Vercel
1. Va sur 👉 https://vercel.com → **"Sign up with GitHub"**
2. Clique **"Add New Project"**
3. Sélectionne le repo **caloritrack**
4. Vercel détecte Vite automatiquement ✅
5. Clique **"Deploy"** → attends 2 minutes
6. Tu obtiens une URL du type : `caloritrack.vercel.app` 🎉

---

## Étape 5 — Installer sur iPhone
1. Ouvre l'URL dans **Safari** (pas Chrome !)
2. Appuie sur le bouton **Partager** (carré avec flèche ↑)
3. Sélectionne **"Sur l'écran d'accueil"**
4. Appuie **"Ajouter"**
5. L'app apparaît sur ton écran comme une vraie app ✅

---

## Mises à jour
Chaque fois que tu modifies un fichier sur GitHub → Vercel redéploie automatiquement en 1 minute.

---

## Structure des fichiers
```
caloritrack/
├── index.html          ← Page principale
├── package.json        ← Dépendances
├── vite.config.js      ← Config build + PWA
├── src/
│   ├── main.jsx        ← Point d'entrée React
│   └── App.jsx         ← Toute l'application
└── public/
    ├── manifest.json   ← Config PWA (icône, nom...)
    ├── icon-192.png    ← Icône app
    └── icon-512.png    ← Icône app haute résolution
```
